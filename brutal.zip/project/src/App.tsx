import React from 'react';
import Header from './components/Header';
import PricingCard from './components/PricingCard';
import Benefits from './components/Benefits';
import FilmStrip from './components/FilmStrip';

function App() {
  const whatsappNumber = "+491638383539";

  return (
    <div className="min-h-screen bg-[url('https://images.unsplash.com/photo-1524712245354-2c4e5e7121c0?w=2400&auto=format&fit=crop&q=80')] bg-cover bg-fixed bg-center before:content-[''] before:absolute before:inset-0 before:bg-black/90 relative overflow-hidden">
      <FilmStrip position="left" />
      <FilmStrip position="right" />
      
      <div className="relative">
        <Header />
        
        <main className="container mx-auto px-4 py-16">
          {/* Hero Section */}
          <div className="text-center mb-16 max-w-4xl mx-auto">
            <div className="mb-8">
              <span className="px-4 py-1 bg-red-600 text-white text-sm rounded-full">
                Premium Streaming Business Opportunity
              </span>
            </div>
            <h1 className="text-6xl font-bold mb-6 text-white">
              Starten Sie Ihr
              <span className="block mt-2 bg-gradient-to-r from-red-500 to-amber-500 text-transparent bg-clip-text">
                IPTV - Imperium
              </span>
            </h1>
            <p className="text-gray-300 text-xl">
              Werden Sie Teil der Elite-Reseller und erschließen Sie sich neue Einkommensquellen. 
              Mit unserem Premium-Streaming-Paket sind Ihrem Erfolg keine Grenzen gesetzt!
            </p>
          </div>

          {/* Animated Divider */}
          <div className="flex items-center justify-center gap-4 mb-16">
            <div className="h-0.5 w-16 bg-gradient-to-r from-red-600 to-amber-500"></div>
            <div className="w-3 h-3 rounded-full bg-red-600 animate-pulse"></div>
            <div className="h-0.5 w-16 bg-gradient-to-r from-amber-500 to-red-600"></div>
          </div>

          {/* Pricing Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-24">
            <PricingCard
              title="Starter Paket"
              price={400}
              credits={120}
              features={[
                "Perfekt für Einsteiger",
                "Full HD Streaming-Qualität",
                "24/7 Technischer Support",
                "Marketing-Materialien inklusive"
              ]}
              whatsappNumber={whatsappNumber}
            />
            <PricingCard
              title="Business Paket"
              price={3000}
              credits={1200}
              features={[
                "Maximale Gewinnmöglichkeiten",
                "4K Ultra HD Streaming",
                "Premium Support-Kanal",
                "Exklusive Gebietsrechte"
              ]}
              isPopular={true}
              whatsappNumber={whatsappNumber}
            />
          </div>

          {/* Benefits Section */}
          <div className="mb-24">
            <h2 className="text-3xl font-bold text-white text-center mb-12">
              Ihre VIP-Vorteile
            </h2>
            <Benefits />
          </div>

          {/* CTA Section */}
          <div className="text-center bg-black/60 backdrop-blur-sm border border-red-500/30 rounded-2xl p-12 mb-16">
            <h2 className="text-3xl font-bold text-white mb-6">
              Bereit für Ihren Erfolg?
            </h2>
            <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
              Schließen Sie sich unserem Netzwerk erfolgreicher Entertainment-Provider an.
              Wählen Sie Ihr Paket und kontaktieren Sie uns über WhatsApp für Ihren VIP-Zugang.
            </p>
            <button className="px-8 py-4 bg-gradient-to-r from-red-600 to-amber-500 rounded-lg text-white font-semibold hover:from-red-500 hover:to-amber-400 transition-all transform hover:scale-105">
              Jetzt durchstarten
            </button>
          </div>
        </main>

        <footer className="bg-black/80 backdrop-blur-sm border-t border-red-500/20 py-8">
          <div className="container mx-auto px-4 text-center text-gray-400">
            <p>© 2024 Premium Streaming Reseller. Alle Rechte vorbehalten.</p>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;