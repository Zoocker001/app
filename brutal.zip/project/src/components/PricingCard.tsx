import React from 'react';
import { Check, ExternalLink, Star } from 'lucide-react';

interface PricingCardProps {
  title: string;
  price: number;
  credits: number;
  features: string[];
  isPopular?: boolean;
  whatsappNumber: string;
}

export default function PricingCard({ title, price, credits, features, isPopular, whatsappNumber }: PricingCardProps) {
  const handleContact = () => {
    window.open(`https://wa.me/${whatsappNumber}?text=Ich interessiere mich für das ${title}`, '_blank');
  };

  return (
    <div
      className={`relative overflow-hidden rounded-2xl transition-all duration-300 transform hover:scale-105 ${
        isPopular
          ? 'bg-gradient-to-br from-red-500/20 to-black border-2 border-red-400 shadow-2xl popular-card'
          : 'bg-black/60 backdrop-blur-sm border border-red-500/30'
      }`}
    >
      {isPopular && (
        <div className="absolute top-5 right-5">
          <span className="flex items-center gap-1 bg-red-500 text-white text-sm font-bold px-3 py-1 rounded-full">
            <Star className="w-4 h-4 fill-current" /> Bestseller
          </span>
        </div>
      )}
      <div className="p-8">
        <h3 className="text-2xl font-bold text-white mb-4">{title}</h3>
        <div className="mb-6">
          <span className="text-5xl font-bold bg-gradient-to-r from-red-400 to-amber-500 text-transparent bg-clip-text">
            €{price}
          </span>
        </div>
        <div className="space-y-4 mb-8">
          <div className="flex items-center gap-3">
            <Check className="w-5 h-5 text-red-500" />
            <span className="text-white">{credits} Credits</span>
          </div>
          <div className="flex items-center gap-3">
            <Check className="w-5 h-5 text-red-500" />
            <span className="text-white">12 Credits = 1 Jahr</span>
          </div>
          <div className="flex items-center gap-3">
            <Check className="w-5 h-5 text-red-500" />
            <span className="text-white">oder 2x 6 Monate</span>
          </div>
          <div className="flex items-center gap-3">
            <Check className="w-5 h-5 text-red-500" />
            <span className="text-white">oder 4x 3 Monate</span>
          </div>
          {features.map((feature, index) => (
            <div key={index} className="flex items-center gap-3">
              <Check className="w-5 h-5 text-red-500" />
              <span className="text-white">{feature}</span>
            </div>
          ))}
        </div>
        <button
          onClick={handleContact}
          className="w-full py-4 px-6 bg-gradient-to-r from-red-600 to-amber-500 rounded-lg text-white font-semibold hover:from-red-500 hover:to-amber-400 transition-all flex items-center justify-center gap-2 group"
        >
          VIP Zugang sichern
          <ExternalLink className="w-5 h-5 transform group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
}