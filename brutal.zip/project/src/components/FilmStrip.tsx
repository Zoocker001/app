import React from 'react';

interface FilmStripProps {
  position: 'left' | 'right';
}

export default function FilmStrip({ position }: FilmStripProps) {
  const baseClasses = "absolute top-0 h-full w-24 opacity-20 pointer-events-none";
  const positionClasses = position === 'left' ? '-left-12 animate-slide-left' : '-right-12 animate-slide-right';
  
  return (
    <div className={`${baseClasses} ${positionClasses}`}>
      {[...Array(20)].map((_, i) => (
        <div key={i} className="w-full h-16 border-y-4 border-red-500 my-4 relative">
          <div className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 bg-red-500 rounded-sm"></div>
          <div className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 bg-red-500 rounded-sm"></div>
        </div>
      ))}
    </div>
  );
}