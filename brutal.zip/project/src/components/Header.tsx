import React from 'react';
import { Film } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-black/60 backdrop-blur-sm border-b border-red-500/20">
      <nav className="container mx-auto px-4 py-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Film className="w-8 h-8 text-red-500" />
          <span  className="text-2xl font-bold bg-gradient-to-r from-red-500 to-amber-500 text-transparent bg-clip-text">
            StreamElite
          </span>
        </div>
        <div className="flex items-center gap-8">
       
        </div>
      </nav>
    </header>
  );
}