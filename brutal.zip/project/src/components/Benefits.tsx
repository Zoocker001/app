import React from 'react';
import { Film, Clapperboard, Award, Headphones } from 'lucide-react';

export default function Benefits() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
      {[
        {
          icon: <Film className="w-10 h-10 text-red-500" />,
          title: "Premium Content",
          description: "Zugang zu den neuesten Filmen und exklusiven Serien"
        },
        {
          icon: <Clapperboard className="w-10 h-10 text-red-500" />,
          title: "4K Qualität",
          description: "Ultra HD Streaming für das ultimative Erlebnis"
        },
        {
          icon: <Award className="w-10 h-10 text-red-500" />,
          title: "VIP Status",
          description: "Exklusive Gebietsrechte und Premium-Support"
        },
        {
          icon: <Headphones className="w-10 h-10 text-red-500" />,
          title: "24/7 Support",
          description: "Rund um die Uhr technische Unterstützung"
        }
      ].map((benefit, index) => (
        <div key={index} className="bg-black/60 backdrop-blur-sm border border-red-500/30 rounded-xl p-6 transform hover:scale-105 transition-all">
          {benefit.icon}
          <h3 className="text-xl font-bold text-white mt-4 mb-2">
            {benefit.title}
          </h3>
          <p className="text-gray-300">
            {benefit.description}
          </p>
        </div>
      ))}
    </div>
  );
}